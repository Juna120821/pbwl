<h2>Dashboard</h2>

<div class="info">Selamat datang, <strong>Muhammad Juarsyah</strong></div>