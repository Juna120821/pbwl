<h2>Selamat Datang</h2>

<div class="info">    
    <h3>
        <a style="color: blue; text-decoration: none" href="<?php echo URL; ?>/log/">Silahkan login</a>
    </h3>
</div>